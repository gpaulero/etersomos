import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sendWhatsAppNotification } from "@/lib/notifications";
import { sendEmail, buildBookingEmail } from "@/lib/email";

/* Helper: ensure the bookings table exists */
async function ensureTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS ReadingBooking (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      readingType TEXT DEFAULT 'Lectura Akáshica Individual',
      preferredDate TEXT,
      preferredTime TEXT,
      message TEXT,
      status TEXT DEFAULT 'pendiente',
      confirmedAt TEXT,
      sentAt TEXT,
      notes TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    )
  `);
}

/* ── POST: Create a new booking + save to DB + send WhatsApp notification ── */

export async function POST(request: NextRequest) {
  try {
    await ensureTable();

    const body = await request.json();
    const { name, email, phone, message } = body;

    if (!name || !email || !phone) {
      return NextResponse.json(
        { error: "Faltan campos obligatorios: nombre, email y teléfono." },
        { status: 400 }
      );
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await db.execute({
      sql: `INSERT INTO ReadingBooking (id, name, email, phone, readingType, message, status, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [
        id,
        name.trim(),
        email.trim().toLowerCase(),
        phone.trim(),
        "Lectura Akáshica Individual",
        message?.trim() || null,
        "pendiente",
        now,
        now,
      ],
    });

    // WhatsApp notification (fire and forget)
    sendWhatsAppNotification({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      readingType: "Lectura Akáshica Individual",
      message: message?.trim() || null,
    }).then((result) => {
      console.log(
        `[WhatsApp Notification] method=${result.method} success=${result.success}`
      );
      if (result.link) {
        console.log(`[WhatsApp Link] ${result.link}`);
      }
    });

    // Email notification (fire and forget)
    const emailPayload = buildBookingEmail({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      readingType: "Lectura Akáshica Individual",
      message: message?.trim() || null,
      createdAt: now,
    });
    sendEmail(emailPayload);

    return NextResponse.json(
      {
        success: true,
        id,
        message: "Solicitud registrada con éxito. Recibirás tu lectura grabada por email en los próximos 5 días hábiles.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error al crear reserva:", error);
    return NextResponse.json(
      { error: "Hubo un error al procesar tu reserva. Intentá de nuevo en unos minutos." },
      { status: 500 }
    );
  }
}

/* ── GET: List bookings (admin) ─────────────────────────────────────────── */

export async function GET() {
  try {
    await ensureTable();

    const result = await db.execute(
      "SELECT * FROM ReadingBooking ORDER BY createdAt DESC"
    );

    const bookings = result.rows;

    const stats = {
      total: bookings.length,
      pendiente: bookings.filter((b) => b.status === "pendiente").length,
      confirmada: bookings.filter((b) => b.status === "confirmada").length,
      en_progreso: bookings.filter((b) => b.status === "en_progreso").length,
      enviada: bookings.filter((b) => b.status === "enviada").length,
      cancelada: bookings.filter((b) => b.status === "cancelada").length,
    };

    return NextResponse.json({ bookings, stats }, { status: 200 });
  } catch (error) {
    console.error("Error al listar reservas:", error);
    return NextResponse.json(
      { error: "Error al obtener las reservas." },
      { status: 500 }
    );
  }
}

/* ── PUT: Update booking status ────────────────────────────────────────── */

export async function PUT(request: NextRequest) {
  try {
    await ensureTable();

    const body = await request.json();
    const { id, status, notes, confirmedAt, sentAt } = body;

    if (!id) {
      return NextResponse.json(
        { error: "Se requiere el ID de la reserva." },
        { status: 400 }
      );
    }

    const updates: string[] = [];
    const args: unknown[] = [];

    if (status) {
      updates.push("status = ?");
      args.push(status);
    }
    if (notes !== undefined) {
      updates.push("notes = ?");
      args.push(notes);
    }
    if (confirmedAt) {
      updates.push("confirmedAt = ?");
      args.push(new Date(confirmedAt).toISOString());
    }
    if (sentAt) {
      updates.push("sentAt = ?");
      args.push(new Date(sentAt).toISOString());
    }

    if (updates.length === 0) {
      return NextResponse.json(
        { error: "No se especificaron campos para actualizar." },
        { status: 400 }
      );
    }

    updates.push("updatedAt = ?");
    args.push(new Date().toISOString());
    args.push(id);

    await db.execute({
      sql: `UPDATE ReadingBooking SET ${updates.join(", ")} WHERE id = ?`,
      args,
    });

    const result = await db.execute({
      sql: "SELECT * FROM ReadingBooking WHERE id = ?",
      args: [id],
    });

    return NextResponse.json(
      { success: true, booking: result.rows[0] },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error al actualizar reserva:", error);
    return NextResponse.json(
      { error: "Error al actualizar la reserva." },
      { status: 500 }
    );
  }
}

/* ── DELETE: Delete a booking ──────────────────────────────────────────── */

export async function DELETE(request: NextRequest) {
  try {
    await ensureTable();

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "Se requiere el ID de la reserva." },
        { status: 400 }
      );
    }

    await db.execute({
      sql: "DELETE FROM ReadingBooking WHERE id = ?",
      args: [id],
    });

    return NextResponse.json(
      { success: true, message: "Reserva eliminada." },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error al eliminar reserva:", error);
    return NextResponse.json(
      { error: "Error al eliminar la reserva." },
      { status: 500 }
    );
  }
}
