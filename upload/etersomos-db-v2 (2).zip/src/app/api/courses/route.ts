import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sendEmail, buildCourseInterestEmail } from "@/lib/email";

/* Helper: ensure the courses_interest table exists */
async function ensureTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS CourseInterest (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      courseName TEXT NOT NULL,
      coursePrice REAL NOT NULL,
      createdAt TEXT NOT NULL
    )
  `);
}

/* ── POST: Register interest in a course ─────────────────────────────── */

export async function POST(request: NextRequest) {
  try {
    await ensureTable();

    const body = await request.json();
    const { name, email, phone, courseName, coursePrice } = body;

    if (!name || !email || !phone || !courseName) {
      return NextResponse.json(
        { error: "Faltan campos obligatorios: nombre, email y teléfono." },
        { status: 400 }
      );
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await db.execute({
      sql: `INSERT INTO CourseInterest (id, name, email, phone, courseName, coursePrice, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
      args: [
        id,
        name.trim(),
        email.trim().toLowerCase(),
        phone.trim(),
        courseName.trim(),
        coursePrice || 0,
        now,
      ],
    });

    // Email notification (fire and forget)
    const emailPayload = buildCourseInterestEmail({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      courseName: courseName.trim(),
      coursePrice: coursePrice || 0,
    });
    sendEmail(emailPayload);

    return NextResponse.json(
      {
        success: true,
        id,
        message: "¡Tu interés quedó registrado! Te contactaremos pronto para abrir inscripciones.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error al registrar interés:", error);
    return NextResponse.json(
      { error: "Hubo un error al procesar tu solicitud. Intentá de nuevo." },
      { status: 500 }
    );
  }
}

/* ── GET: List course interests (admin) ──────────────────────────────── */

export async function GET() {
  try {
    await ensureTable();

    const result = await db.execute(
      "SELECT * FROM CourseInterest ORDER BY createdAt DESC"
    );

    return NextResponse.json({ interests: result.rows }, { status: 200 });
  } catch (error) {
    console.error("Error al listar intereses:", error);
    return NextResponse.json(
      { error: "Error al obtener los intereses." },
      { status: 500 }
    );
  }
}
