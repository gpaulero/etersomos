import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sendEmail, buildCrystalOrderEmail } from "@/lib/email";

/* Helper: ensure the crystal_orders table exists */
async function ensureTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS CrystalOrder (
      id TEXT PRIMARY KEY,
      customerName TEXT NOT NULL,
      customerEmail TEXT NOT NULL,
      customerPhone TEXT NOT NULL,
      items TEXT NOT NULL,
      total REAL NOT NULL,
      status TEXT DEFAULT 'pendiente',
      createdAt TEXT NOT NULL
    )
  `);
}

/* ── POST: Create crystal order ──────────────────────────────────────── */

export async function POST(request: NextRequest) {
  try {
    await ensureTable();

    const body = await request.json();
    const { name, email, phone, items, total } = body;

    if (!name || !email || !phone || !items || !items.length) {
      return NextResponse.json(
        { error: "Faltan campos obligatorios." },
        { status: 400 }
      );
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await db.execute({
      sql: `INSERT INTO CrystalOrder (id, customerName, customerEmail, customerPhone, items, total, status, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [
        id,
        name.trim(),
        email.trim().toLowerCase(),
        phone.trim(),
        JSON.stringify(items),
        total,
        "pendiente",
        now,
      ],
    });

    // Email notification (fire and forget)
    const emailPayload = buildCrystalOrderEmail({
      items,
      total,
      customerName: name.trim(),
      customerEmail: email.trim().toLowerCase(),
      customerPhone: phone.trim(),
    });
    sendEmail(emailPayload);

    return NextResponse.json(
      {
        success: true,
        id,
        message: "¡Pedido registrado con éxito! Te contactaremos por WhatsApp para coordinar el envío.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error al crear pedido:", error);
    return NextResponse.json(
      { error: "Hubo un error al procesar tu pedido. Intentá de nuevo." },
      { status: 500 }
    );
  }
}

/* ── GET: List crystal orders (admin) ────────────────────────────────── */

export async function GET() {
  try {
    await ensureTable();

    const result = await db.execute(
      "SELECT * FROM CrystalOrder ORDER BY createdAt DESC"
    );

    const orders = result.rows.map((row) => ({
      ...row,
      items: JSON.parse((row.items as string) || "[]"),
    }));

    return NextResponse.json({ orders }, { status: 200 });
  } catch (error) {
    console.error("Error al listar pedidos:", error);
    return NextResponse.json(
      { error: "Error al obtener los pedidos." },
      { status: 500 }
    );
  }
}
