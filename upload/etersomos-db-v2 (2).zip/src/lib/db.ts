import { createClient, Client } from "@libsql/client";

const globalForDb = globalThis as unknown as {
  turso: Client | undefined;
};

export const db =
  globalForDb.turso ??
  createClient({
    url: process.env.DATABASE_URL!,
    authToken: process.env.DATABASE_AUTH_TOKEN,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.turso = db;
}
