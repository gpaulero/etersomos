import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "etersomos@gmail.com";

interface EmailPayload {
  to: string;
  subject: string;
  html: string;
}

/* ── Send email helper ──────────────────────────────────────────────── */

export async function sendEmail({ to, subject, html }: EmailPayload): Promise<{
  success: boolean;
  error?: string;
}> {
  if (!process.env.RESEND_API_KEY) {
    console.log("[Email] No API key configured, skipping email send");
    return { success: false, error: "No API key configured" };
  }

  try {
    const { error } = await resend.emails.send({
      from: "Eter Somos <onboarding@resend.dev>",
      to,
      subject,
      html,
    });

    if (error) {
      console.error("[Email] Error:", error);
      return { success: false, error: error.message };
    }

    console.log("[Email] Sent successfully to:", to);
    return { success: true };
  } catch (err) {
    console.error("[Email] Exception:", err);
    return { success: false, error: String(err) };
  }
}

/* ── New Reading Booking Email ───────────────────────────────────────── */

export function buildBookingEmail(booking: {
  name: string;
  email: string;
  phone: string;
  readingType: string;
  message?: string | null;
  createdAt?: string;
}): EmailPayload {
  const date = booking.createdAt
    ? new Date(booking.createdAt).toLocaleString("es-AR", {
        day: "2-digit",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : new Date().toLocaleString("es-AR", {
        day: "2-digit",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });

  const messageBlock = booking.message
    ? `<tr><td style="padding:8px 0;color:#6b5e4f;font-size:14px;"><strong>Mensaje:</strong> ${booking.message}</td></tr>`
    : "";

  return {
    to: ADMIN_EMAIL,
    subject: `✨ Nueva Lectura Akáshica - ${booking.name}`,
    html: `
      <div style="font-family:'Segoe UI',sans-serif;max-width:600px;margin:0 auto;background:#0f0d0b;border-radius:12px;padding:32px;border:1px solid #2a2520;">
        <div style="text-align:center;margin-bottom:24px;">
          <h1 style="color:#bfb09a;font-size:24px;margin:0;">✨ Nueva Solicitud de Lectura</h1>
          <p style="color:#6b5e4f;font-size:13px;margin-top:4px;">Eter Somos — Registros Akáshicos</p>
        </div>
        <div style="background:#161310;border-radius:8px;padding:20px;border:1px solid #2a252066;">
          <table style="width:100%;border-collapse:collapse;">
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;width:120px;"><strong>Nombre</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${booking.name}</td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Email</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="mailto:${booking.email}" style="color:#bfb09a;">${booking.email}</a></td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Teléfono</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="https://wa.me/${booking.phone.replace(/[^0-9]/g, "")}" style="color:#bfb09a;">${booking.phone}</a></td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Servicio</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${booking.readingType}</td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Fecha</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${date}</td></tr>
            ${messageBlock}
          </table>
        </div>
        <div style="text-align:center;margin-top:20px;padding:16px;background:#1a1714;border-radius:8px;border:1px solid #2a252066;">
          <p style="color:#bfb09a;font-size:13px;margin:0;">⏰ Recordá: Enviar la lectura grabada por email dentro de los 5 días hábiles.</p>
        </div>
      </div>
    `,
  };
}

/* ── Course Interest Email ───────────────────────────────────────────── */

export function buildCourseInterestEmail(data: {
  name: string;
  email: string;
  phone: string;
  courseName: string;
  coursePrice: number;
}): EmailPayload {
  return {
    to: ADMIN_EMAIL,
    subject: `📚 Interés en ${data.courseName} — ${data.name}`,
    html: `
      <div style="font-family:'Segoe UI',sans-serif;max-width:600px;margin:0 auto;background:#0f0d0b;border-radius:12px;padding:32px;border:1px solid #2a2520;">
        <div style="text-align:center;margin-bottom:24px;">
          <h1 style="color:#bfb09a;font-size:24px;margin:0;">📚 Nueva Inscripción a Curso</h1>
          <p style="color:#6b5e4f;font-size:13px;margin-top:4px;">Eter Somos — Formaciones</p>
        </div>
        <div style="background:#161310;border-radius:8px;padding:20px;border:1px solid #2a252066;">
          <table style="width:100%;border-collapse:collapse;">
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;width:120px;"><strong>Nombre</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${data.name}</td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Email</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="mailto:${data.email}" style="color:#bfb09a;">${data.email}</a></td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Teléfono</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="https://wa.me/${data.phone.replace(/[^0-9]/g, "")}" style="color:#bfb09a;">${data.phone}</a></td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Curso</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${data.courseName}</td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Precio</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">$${data.coursePrice.toLocaleString("es-AR")} ARS</td></tr>
          </table>
        </div>
        <div style="text-align:center;margin-top:20px;padding:16px;background:#1a1714;border-radius:8px;border:1px solid #2a252066;">
          <p style="color:#bfb09a;font-size:13px;margin:0;">Contactá a esta persona para confirmar su inscripción.</p>
        </div>
      </div>
    `,
  };
}

/* ── Crystal Purchase Email ──────────────────────────────────────────── */

export function buildCrystalOrderEmail(data: {
  items: { name: string; price: number; quantity: number }[];
  total: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
}): EmailPayload {
  const itemsRows = data.items
    .map(
      (item) => `
      <tr>
        <td style="padding:10px 0;color:#f0ebe5;font-size:14px;border-bottom:1px solid #2a252066;">${item.name} x${item.quantity}</td>
        <td style="padding:10px 0;color:#bfb09a;font-size:14px;text-align:right;border-bottom:1px solid #2a252066;">$${(item.price * item.quantity).toLocaleString("es-AR")} ARS</td>
      </tr>`
    )
    .join("");

  return {
    to: ADMIN_EMAIL,
    subject: `💎 Nuevo Pedido de Cristales — ${data.customerName}`,
    html: `
      <div style="font-family:'Segoe UI',sans-serif;max-width:600px;margin:0 auto;background:#0f0d0b;border-radius:12px;padding:32px;border:1px solid #2a2520;">
        <div style="text-align:center;margin-bottom:24px;">
          <h1 style="color:#bfb09a;font-size:24px;margin:0;">💎 Nuevo Pedido de Cristales</h1>
          <p style="color:#6b5e4f;font-size:13px;margin-top:4px;">Eter Somos — Tienda</p>
        </div>
        <div style="background:#161310;border-radius:8px;padding:20px;border:1px solid #2a252066;margin-bottom:16px;">
          <table style="width:100%;border-collapse:collapse;">
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;width:120px;"><strong>Nombre</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;">${data.customerName}</td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Email</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="mailto:${data.customerEmail}" style="color:#bfb09a;">${data.customerEmail}</a></td></tr>
            <tr><td style="padding:8px 0;color:#bfb09a;font-size:14px;"><strong>Teléfono</strong></td><td style="padding:8px 0;color:#f0ebe5;font-size:14px;"><a href="https://wa.me/${data.customerPhone.replace(/[^0-9]/g, "")}" style="color:#bfb09a;">${data.customerPhone}</a></td></tr>
          </table>
        </div>
        <div style="background:#161310;border-radius:8px;padding:20px;border:1px solid #2a252066;">
          <h3 style="color:#bfb09a;font-size:16px;margin:0 0 12px 0;">Productos</h3>
          <table style="width:100%;border-collapse:collapse;">
            ${itemsRows}
            <tr>
              <td style="padding:12px 0 0 0;color:#f0ebe5;font-size:16px;font-weight:bold;">Total</td>
              <td style="padding:12px 0 0 0;color:#bfb09a;font-size:16px;font-weight:bold;text-align:right;">$${data.total.toLocaleString("es-AR")} ARS</td>
            </tr>
          </table>
        </div>
        <div style="text-align:center;margin-top:20px;padding:16px;background:#1a1714;border-radius:8px;border:1px solid #2a252066;">
          <p style="color:#bfb09a;font-size:13px;margin:0;">Contactá al cliente para coordinar el envío.</p>
        </div>
      </div>
    `,
  };
}
